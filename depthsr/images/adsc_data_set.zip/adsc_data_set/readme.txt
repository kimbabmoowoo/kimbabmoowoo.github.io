bilinear_int: bilinear interpolation
gf: guided filter [1]
rwr: randon walk with restart [2]
atgv: anisotropic total generalized variation [3]
wmedf: weighted median filter [4]
wmodf: weighted mode filter [5]
nmedf: nonlocal weighted median filter [6]
proposed: proposed method
intensity: intensity image

[1] K. He, J. Sun, and X. Tang, "Guided image filtering,� in Proc. Eur. Conf. Comput. Vis., pp. 1-14, 2010.
[2] B. Ham, D. Min, and K. Sohn, "A generalized random walk with restart and its application in depth up-sampling and interactive segmentation,� IEEE Trans. Image Process., vol. 22, no. 7, pp. 2574-2588, 2013.
[3] D. Ferstl, C. Reinbacher, R. Ranftl, M. R��uther, and H. Bischof, "Image guided depth upsampling using anisotropic total generalized variation,� in Proc. Int. Conf. Comput. Vis., pp. 993-1000, 2013.
[4] Z. Ma, K. He, Y. Wei, J. Sun, and E. Wu, "Constant time weighted median filtering for stereo matching and beyond,� in Proc. Int. Conf. Comput. Vis., pp. 49-56, 2013.
[5] D. Min, J. Lu, and M. Do, "Depth video enhancement based on weighted mode filtering,� IEEE Trans. Image Process., vol. 21, no. 3, pp. 1176-1190, 2012.
[6] Q. Yang, �Stereo matching using tree filtering,� IEEE Trans. Pattern Anal. Mach. Intell., 2015.