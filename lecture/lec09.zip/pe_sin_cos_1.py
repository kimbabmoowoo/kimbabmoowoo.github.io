import torch
import math
import matplotlib.pyplot as plt

# ============================================================
# Generate sinusoidal positional encoding 
# ============================================================

def generate_positional_encoding(d_model, max_len=200):

    # pe shape: (max_len, d_model)
    pe = torch.zeros(max_len, d_model)

    # positions: 0 .. max_len-1, shape = (max_len, 1)
    position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)

    # frequency term for even dimensions
    div_term = torch.exp(
        torch.arange(0, d_model, 2, dtype=torch.float32)
        * (-math.log(10000.0) / d_model)
    )

    # Even indices: sin, shape broadcasting: (max_len, 1) * (1, d_model/2)
    pe[:, 0::2] = torch.sin(position * div_term)
    # Odd indices: cos
    pe[:, 1::2] = torch.cos(position * div_term)

    return pe  # (max_len, d_model)


# ============================================================
# Visualization: separate heatmaps for sin and cos
# ============================================================

d_model = 64   # embedding dimension
max_len = 200  # number of positions

pe = generate_positional_encoding(d_model, max_len)  # (max_len, d_model)

# Extract even (sin) and odd (cos) dimensions
# sin_part: shape (max_len, d_model/2)
# cos_part: shape (max_len, d_model/2)
sin_part = pe[:, 0::2]
cos_part = pe[:, 1::2]

# ----- Heatmap 1: Sine components (even dimensions) -----
plt.figure(figsize=(10, 5))
plt.imshow(sin_part, aspect="auto", origin="lower", cmap="viridis")
plt.colorbar(label="Value")
plt.xlabel("Even Embedding Dimension Index (0, 2, 4, ...)")
plt.ylabel("Position")
plt.title("Sinusoidal Positional Encoding - Sine Part (Even Dimensions)")
plt.tight_layout()

# ----- Heatmap 2: Cosine components (odd dimensions) -----
plt.figure(figsize=(10, 5))
plt.imshow(cos_part, aspect="auto", origin="lower", cmap="viridis")
plt.colorbar(label="Value")
plt.xlabel("Odd Embedding Dimension Index (1, 3, 5, ...)")
plt.ylabel("Position")
plt.title("Sinusoidal Positional Encoding - Cosine Part (Odd Dimensions)")
plt.tight_layout()

plt.show()
