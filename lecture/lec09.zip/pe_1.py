import torch
import math
import matplotlib.pyplot as plt

# ============================================================
# Generate sinusoidal positional encoding 
# ============================================================

def generate_positional_encoding(d_model, max_len=200):

    # pe shape: (max_len, d_model)
    pe = torch.zeros(max_len, d_model)

    # positions: 0 .. max_len-1, shape = (max_len, 1)
    position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)

    # Compute the denominator term for frequency scaling
    div_term = torch.exp(
        torch.arange(0, d_model, 2, dtype=torch.float32)
        * (-math.log(10000.0) / d_model)
    )

    # Apply sin to even dimensions, cos to odd dimensions
    pe[:, 0::2] = torch.sin(position * div_term)  # even index columns
    pe[:, 1::2] = torch.cos(position * div_term)  # odd index columns

    return pe  # (max_len, d_model)


# ============================================================
# Visualization
# ============================================================

d_model = 64   # number of embedding dimensions (x-axis)
max_len = 200  # number of positions (y-axis)

pe = generate_positional_encoding(d_model, max_len)  # shape = (200, 64)

plt.figure(figsize=(10, 6))

# imshow expects (rows, cols) = (positions, dimensions)
plt.imshow(pe, cmap="viridis", aspect="auto", origin="lower")

plt.xlabel("Embedding Dimension")
plt.ylabel("Position")
plt.title("Sinusoidal Positional Encoding (from 'Attention is All You Need')")
plt.colorbar(label="Encoding Value")

plt.show()