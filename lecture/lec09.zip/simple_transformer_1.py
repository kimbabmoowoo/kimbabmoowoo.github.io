import math
import torch
import torch.nn as nn
import torch.nn.functional as F

# ============================================================
# 1. Positional Encoding (sinusoidal, as in the paper)
# ============================================================

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding from "Attention is All You Need".
    This has no learnable parameters.
    """
    def __init__(self, d_model, max_len=5000):
        super().__init__()

        # pe: (max_len, d_model)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32)
            * (-math.log(10000.0) / d_model)
        )
        # Even indices: sin
        pe[:, 0::2] = torch.sin(position * div_term)
        # Odd indices: cos
        pe[:, 1::2] = torch.cos(position * div_term)

        # Register as buffer so it is saved with the model but not a parameter
        self.register_buffer("pe", pe.unsqueeze(0))  # (1, max_len, d_model)

    def forward(self, x):
        """
        x: (batch_size, seq_len, d_model)
        """
        seq_len = x.size(1)
        # Add positional encoding (broadcast along batch dimension)
        x = x + self.pe[:, :seq_len, :]
        return x


# ============================================================
# 2. Scaled Dot-Product Attention + Multi-Head Attention
# ============================================================

def scaled_dot_product_attention(q, k, v, mask=None):
    """
    q, k, v: (batch, heads, seq_len, head_dim)
    mask: (batch, 1, 1, seq_len_k) or broadcastable shape (optional)
    """
    d_k = q.size(-1)
    scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(d_k)  # (B, H, L_q, L_k)

    if mask is not None:
        # mask == 0 -> masked out
        scores = scores.masked_fill(mask == 0, float("-inf"))

    attn = F.softmax(scores, dim=-1)
    out = torch.matmul(attn, v)  # (B, H, L_q, head_dim)
    return out, attn


class MultiHeadAttention(nn.Module):
    """
    Multi-head attention as in the Transformer paper.
    """
    def __init__(self, d_model, num_heads, dropout=0.1):
        super().__init__()
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"

        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        # Linear projections for q, k, v
        self.w_q = nn.Linear(d_model, d_model)
        self.w_k = nn.Linear(d_model, d_model)
        self.w_v = nn.Linear(d_model, d_model)

        # Final linear layer
        self.w_o = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(dropout)

    def forward(self, q, k, v, mask=None):
        """
        q, k, v: (batch, seq_len, d_model)
        mask: (batch, 1, 1, seq_len_k) or broadcastable
        """
        B, L_q, _ = q.size()
        B, L_k, _ = k.size()
        B, L_v, _ = v.size()

        # Linear projections
        q = self.w_q(q)  # (B, L_q, d_model)
        k = self.w_k(k)  # (B, L_k, d_model)
        v = self.w_v(v)  # (B, L_v, d_model)

        # Reshape to (B, H, L, head_dim)
        q = q.view(B, L_q, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(B, L_k, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(B, L_v, self.num_heads, self.head_dim).transpose(1, 2)

        # Apply scaled dot-product attention
        out, attn = scaled_dot_product_attention(q, k, v, mask=mask)

        # Concatenate heads
        out = out.transpose(1, 2).contiguous().view(B, L_q, self.d_model)

        # Final linear + dropout
        out = self.w_o(out)
        out = self.dropout(out)
        return out


# ============================================================
# 3. Position-wise Feed-Forward Network
# ============================================================

class PositionwiseFeedForward(nn.Module):
    """
    Two-layer feed-forward network applied at each position.
    FFN(x) = max(0, xW1 + b1)W2 + b2
    """
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.fc1 = nn.Linear(d_model, d_ff)
        self.fc2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.dropout(x)
        x = self.fc2(x)
        return x


# ============================================================
# 4. Encoder & Decoder layers
# ============================================================

class EncoderLayer(nn.Module):
    """
    One encoder layer = self-attention + feed-forward, with residual + layernorm.
    """
    def __init__(self, d_model, num_heads, d_ff, dropout=0.1):
        super().__init__()
        self.self_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.ff = PositionwiseFeedForward(d_model, d_ff, dropout)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, src_mask=None):
        # Self-attention sublayer
        attn_out = self.self_attn(x, x, x, mask=src_mask)
        x = x + self.dropout(attn_out)
        x = self.norm1(x)

        # Feed-forward sublayer
        ff_out = self.ff(x)
        x = x + self.dropout(ff_out)
        x = self.norm2(x)

        return x


class DecoderLayer(nn.Module):
    """
    One decoder layer = masked self-attention + encoder-decoder attention + feed-forward.
    """
    def __init__(self, d_model, num_heads, d_ff, dropout=0.1):
        super().__init__()
        self.self_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.cross_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.ff = PositionwiseFeedForward(d_model, d_ff, dropout)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, memory, tgt_mask=None, memory_mask=None):
        # Masked self-attention (decoder attends to previous positions)
        self_attn_out = self.self_attn(x, x, x, mask=tgt_mask)
        x = x + self.dropout(self_attn_out)
        x = self.norm1(x)

        # Encoder-decoder attention (decoder queries, encoder keys/values)
        cross_attn_out = self.cross_attn(x, memory, memory, mask=memory_mask)
        x = x + self.dropout(cross_attn_out)
        x = self.norm2(x)

        # Feed-forward
        ff_out = self.ff(x)
        x = x + self.dropout(ff_out)
        x = self.norm3(x)

        return x


# ============================================================
# 5. Full Encoder, Decoder, and Transformer model
# ============================================================

class Encoder(nn.Module):
    def __init__(self, vocab_size, d_model, num_layers, num_heads, d_ff,
                 max_len=5000, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_enc = PositionalEncoding(d_model, max_len)

        self.layers = nn.ModuleList(
            [EncoderLayer(d_model, num_heads, d_ff, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, src, src_mask=None):
        """
        src: (batch, src_len)
        src_mask: (batch, 1, 1, src_len) where 1=keep, 0=mask
        """
        x = self.embed(src) * math.sqrt(self.d_model)
        x = self.pos_enc(x)
        x = self.dropout(x)

        for layer in self.layers:
            x = layer(x, src_mask=src_mask)

        return x  # (batch, src_len, d_model)


class Decoder(nn.Module):
    def __init__(self, vocab_size, d_model, num_layers, num_heads, d_ff,
                 max_len=5000, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_enc = PositionalEncoding(d_model, max_len)

        self.layers = nn.ModuleList(
            [DecoderLayer(d_model, num_heads, d_ff, dropout) for _ in range(num_layers)]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, tgt, memory, tgt_mask=None, memory_mask=None):
        """
        tgt: (batch, tgt_len)
        memory: encoder outputs (batch, src_len, d_model)
        tgt_mask: (batch, 1, tgt_len, tgt_len)
        memory_mask: (batch, 1, 1, src_len)
        """
        x = self.embed(tgt) * math.sqrt(self.d_model)
        x = self.pos_enc(x)
        x = self.dropout(x)

        for layer in self.layers:
            x = layer(x, memory, tgt_mask=tgt_mask, memory_mask=memory_mask)

        return x  # (batch, tgt_len, d_model)


class SimpleTransformer(nn.Module):
    """
    Compact encoder-decoder Transformer, following "Attention is All You Need".
    For real MT you would add label smoothing, beam search, etc.
    """
    def __init__(
        self,
        src_vocab_size,
        tgt_vocab_size,
        d_model=256,      # Paper uses 512
        num_layers=2,     # Paper uses 6
        num_heads=4,      # Paper uses 8
        d_ff=512,         # Paper uses 2048
        max_len=5000,
        dropout=0.1,
    ):
        super().__init__()
        self.encoder = Encoder(src_vocab_size, d_model, num_layers, num_heads, d_ff, max_len, dropout)
        self.decoder = Decoder(tgt_vocab_size, d_model, num_layers, num_heads, d_ff, max_len, dropout)
        self.tgt_proj = nn.Linear(d_model, tgt_vocab_size)

        # (Optional) tie weights with target embedding:
        # self.tgt_proj.weight = self.decoder.embed.weight

    def forward(self, src, tgt, src_mask=None, tgt_mask=None, memory_mask=None):
        """
        src: (batch, src_len)
        tgt: (batch, tgt_len)
        """
        memory = self.encoder(src, src_mask=src_mask)
        dec_out = self.decoder(tgt, memory, tgt_mask=tgt_mask, memory_mask=memory_mask)
        logits = self.tgt_proj(dec_out)  # (batch, tgt_len, tgt_vocab_size)
        return logits


# ============================================================
# 6. Mask helpers (padding mask, subsequent mask)
# ============================================================

def create_padding_mask(seq, pad_idx):
    """
    seq: (batch, seq_len)
    Returns mask of shape (batch, 1, 1, seq_len)
    1 = keep, 0 = mask out
    """
    mask = (seq != pad_idx).unsqueeze(1).unsqueeze(2)  # (B,1,1,L)
    return mask  # bool / byte mask


def create_subsequent_mask(size):
    """
    Mask out future positions for decoder self-attention.
    Returns (1, 1, size, size) lower-triangular mask.
    """
    mask = torch.tril(torch.ones(size, size, dtype=torch.uint8))
    return mask.unsqueeze(0).unsqueeze(0)  # (1,1,L,L)


def create_tgt_mask(tgt, pad_idx):
    """
    Combine padding mask and subsequent mask for target.
    """
    B, L = tgt.size()
    pad_mask = create_padding_mask(tgt, pad_idx)       # (B,1,1,L)
    subseq_mask = create_subsequent_mask(L).to(tgt.device)  # (1,1,L,L)
    # Broadcast & combine (logical AND)
    mask = pad_mask & subseq_mask  # (B,1,L,L)
    return mask


# ============================================================
# 7. Simple example with dummy data
# ============================================================

if __name__ == "__main__":
    # Dummy vocabulary sizes
    src_vocab_size = 1000
    tgt_vocab_size = 1000
    pad_idx = 0

    # Create model (smaller than paper for teaching / debugging)
    model = SimpleTransformer(
        src_vocab_size=src_vocab_size,
        tgt_vocab_size=tgt_vocab_size,
        d_model=256,   # try 512 for paper-like
        num_layers=2,  # try 6 for paper-like
        num_heads=4,   # try 8 for paper-like
        d_ff=512,      # try 2048 for paper-like
    )

    # Dummy batch: (batch_size=2, src_len=5, tgt_len=6)
    src = torch.tensor([[1, 2, 3, 4, 0],
                        [5, 6, 7, 0, 0]], dtype=torch.long)
    tgt = torch.tensor([[1, 2, 3, 0, 0, 0],
                        [4, 5, 0, 0, 0, 0]], dtype=torch.long)

    src_mask = create_padding_mask(src, pad_idx)       # (B,1,1,src_len)
    tgt_mask = create_tgt_mask(tgt, pad_idx)           # (B,1,tgt_len,tgt_len)
    memory_mask = src_mask                             # encoder padding mask

    logits = model(src, tgt, src_mask=src_mask, tgt_mask=tgt_mask, memory_mask=memory_mask)
    print("Logits shape:", logits.shape)  # (2, tgt_len, tgt_vocab_size)
