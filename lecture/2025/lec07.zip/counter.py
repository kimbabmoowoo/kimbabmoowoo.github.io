from collections import Counter

counter = Counter()       # create an empty counter
# counter.update(["cat", "dog", "cat"])
# counter.update(["cat", "cow"])

# counter.update("hello")
# print(counter)

texts = ["I like cats.", "I like dogs"]

for text in texts:
    tokens = text.lower().split()
    counter.update(tokens)

#print(counter)


# text = "I LIKE CATS"
# print(text.lower())
# print(text.lower().split())

# tokens = ["cat", "dog", "cat", "bird", "cat", "dog"]
# counter = Counter(tokens)

# print(counter.most_common())

# ==================================================
text = "I like dogs and I like cats and I like animals"
words = text.lower().split()   # very simple tokenization

counter = Counter(words)

# for word, freq in counter.most_common():
#     print(word, "→", freq)

# ==================================================
animals = "catdogcatcat"
counter = Counter(animals)

print(counter.most_common(1))