person = {"name": "Minsoo", "age": 25}

# print(person.get("name"))         # Minsoo
# print(person.get("job"))          # None (because "job" doesn't exist)
# print(person.get("job", "Not Allowed"))   # N/A (default value is returned)

# print(person["name"])
# print(person["job"])

#===================================================
toks = ["How", "are", "you?"]
text = ':'.join(toks)
print(text)

text = ' '.join(toks)
print(text)