import re

text = "I like cats and dogs."

# find all words
# \w = letters, numbers, underscore
words = re.findall(r"\w+", text)
#print(words)

#-------------------------------------------------
import re

text = "Hello, world! How are you?"

# find all punctuation
# punct = re.findall(r"[,.!?]", text)
punct = re.findall(r"[^\w\s]", text)
#print(punct)

#-------------------------------------------------
#tokens = re.findall(r"[A-Za-z0-9]+|[^\sA-Za-z0-9]", text)
#print(tokens)

#-------------------------------------------------
text = "I like cats !"

# clean = re.sub(r"\s+([!?.,])", r"\1", text)
# print(clean)

tokens = re.findall(r"[A-Za-z0-9]+|[^\sA-Za-z0-9]", text)
#print(tokens)

#-------------------------------------------------
text = "I have a cat and a dog."

tokens = re.findall(r"cat|dog", text)
print(tokens)