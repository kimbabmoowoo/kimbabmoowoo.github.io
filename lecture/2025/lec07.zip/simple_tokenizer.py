# (build vocab → encode → decode)

import re
from collections import Counter

PAD, UNK, BOS, EOS = "<pad>", "<unk>", "<bos>", "<eos>"

def tokenize(text, lowercase=True):
    if lowercase: 
        text = text.lower()
    
    # Split on whitespace, keep punctuation as separate tokens
    return re.findall(r"[A-Za-z0-9]+|[^\sA-Za-z0-9]", text)

def build_vocab(texts, min_freq=1, lowercase=True):
    counter = Counter()
    for t in texts:
        counter.update(tokenize(t, lowercase))
    
    # places the special tokens at the beginning of the vocabulary BEFORE adding normal words
    id2tok = [PAD, UNK, BOS, EOS]
    for tok, freq in counter.most_common():
        if freq >= min_freq and tok not in id2tok:
            id2tok.append(tok)

    tok2id = {t: i for i, t in enumerate(id2tok)}

    return tok2id, id2tok

def encode(text, tok2id, add_specials=True, lowercase=True):
    toks = tokenize(text, lowercase)

    ids = [tok2id.get(t, tok2id[UNK]) for t in toks]

    if add_specials:
        ids = [tok2id[BOS]] + ids + [tok2id[EOS]]

    return ids  # wrap with torch.tensor(ids) if you want tensors

def decode(ids, id2tok, strip_specials=True):
    toks = [id2tok[i] for i in ids if 0 <= i < len(id2tok)]

    if strip_specials:
        toks = [t for t in toks if t not in {PAD, BOS, EOS}]

    # Simple detokenization: join then fix space before punctuation
    text = " ".join(toks)
    text = re.sub(r"\s+([,.!?;:])", r"\1", text)
    return text

# ---- simple demo ----
if __name__ == "__main__":
    corpus = [
        "I like cats.",
        "I like dogs a lot!",
        "Cats are cute; dogs are loyal."
    ]
    tok2id, id2tok = build_vocab(corpus, min_freq=1, lowercase=True)

    s = "I really like cats!"
    ids = encode(s, tok2id, add_specials=True, lowercase=True)
    print("Encoded:", ids)
    print("Decoded:", decode(ids, id2tok))
    print(id2tok)