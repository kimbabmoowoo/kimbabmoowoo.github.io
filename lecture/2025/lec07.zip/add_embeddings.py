import torch
import torch.nn as nn

id2tok = ['<pad>', '<unk>', '<bos>', '<eos>', 'i', 'like', 'cats', 
          '.', 'dogs', 'are', 'a', 'lot', '!', 'cute', ';', 'loyal']
ids = [2, 4, 1, 5, 6, 12, 3]

vocab_size = len(id2tok)  
embedding_dim = 16

embedding = nn.Embedding(vocab_size, embedding_dim)

ids = torch.tensor([ids])  # batch of size 1
embedded = embedding(ids)

print(embedded.shape)   # (1, seq_len, 16)
print(embedded)