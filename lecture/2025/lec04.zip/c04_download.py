import os, urllib.request

# Target folder
target_dir = os.path.join(".", "my_data", "MNIST", "raw")
os.makedirs(target_dir, exist_ok=True)

# One MNIST file (train images)
url = "https://storage.googleapis.com/cvdf-datasets/mnist/train-images-idx3-ubyte.gz"
out_path = os.path.join(target_dir, "train-images-idx3-ubyte.gz")

# Download file
urllib.request.urlretrieve(url, out_path)

print("OK. Download complete:", out_path)