import os
import urllib.request

# Target directory
target_dir = os.path.join(".", "data", "MNIST", "raw")
os.makedirs(target_dir, exist_ok=True)

# Files to download (from Google Cloud mirror)
base_url = "https://storage.googleapis.com/cvdf-datasets/mnist/"
files = [
    "train-images-idx3-ubyte.gz",
    "train-labels-idx1-ubyte.gz",
    "t10k-images-idx3-ubyte.gz",
    "t10k-labels-idx1-ubyte.gz",
]

print(f"Downloading MNIST dataset into {target_dir} ...")

for fname in files:
    url = base_url + fname
    out_path = os.path.join(target_dir, fname)
    if not os.path.exists(out_path):
        print(f" -> {fname}")
        urllib.request.urlretrieve(url, out_path)
    else:
        print(f" [skip] {fname} already exists")

print("OK! MNIST dataset is ready in ./data/MNIST/raw/")
