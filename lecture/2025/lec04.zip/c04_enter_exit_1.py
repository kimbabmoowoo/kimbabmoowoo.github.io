class DummyContext:
    # Context manager using __enter__ and __exit__.
    def __enter__(self):
        print("Entering context")
        return "Resource Acquired"
    def __exit__(self, exc_type, exc_val, exc_tb):
        print("Exiting context")

# The standard way to open a file using 'with'
with open('example.txt', 'w') as f:
    f.write("This is a test.")

#Context manager
with DummyContext() as res:
    print(res)
