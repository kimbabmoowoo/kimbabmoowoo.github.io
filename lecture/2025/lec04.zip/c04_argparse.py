import argparse

def main():
    # 1. Create parser
    parser = argparse.ArgumentParser(description="my simple code")

    # 2. Add argument for number of iterations
    parser.add_argument("my_iterations", type=int, default=5,
                        help="Number of times to run the loop (default: 5)")

    # 3. Parse arguments
    args = parser.parse_args()

    # 4. Use iterations in a for loop
    for i in range(args.my_iterations):
        print(f"Iteration {i+1}")

if __name__ == "__main__":
    main()
