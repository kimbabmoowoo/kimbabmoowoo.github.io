import torch
import torch.nn as nn

# (Example) batch of 32 samples, each with 128 features
x = torch.randn(32, 128)

# -------------------------
# Batch Normalization (using nn.BatchNorm1d( ))
# -------------------------
bn = nn.BatchNorm1d(128)   # 128 features
out_bn = bn(x)

print("BN output shape:", out_bn.shape)

# -------------------------
# Layer Normalization (using nn.LayerNorm( ))
# -------------------------
ln = nn.LayerNorm(128)     # 128 features
out_ln = ln(x)

print("LN output shape:", out_ln.shape)