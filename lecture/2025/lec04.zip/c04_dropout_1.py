import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# ====== Config ======
BATCH_SIZE = 128
EPOCHS = 5
LR = 1e-3
DROPOUT = 0.2
NUM_CLASSES = 10

# ====== Model ======
class SimpleNetMNIST(nn.Module):
    def __init__(self, p_drop=0.2):
        super().__init__()
        self.fc1 = nn.Linear(28 * 28, 128)
        self.drop1 = nn.Dropout(p=p_drop)
        self.fc2 = nn.Linear(128, 64)
        self.drop2 = nn.Dropout(p=p_drop)
        self.fc3 = nn.Linear(64, NUM_CLASSES)

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x)); x = self.drop1(x)
        x = F.relu(self.fc2(x)); x = self.drop2(x)
        return self.fc3(x)

def main():
    torch.manual_seed(0)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # ----- Data (train only) -----
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])
    train_ds = datasets.MNIST(root="./data", train=True, download=True, transform=transform)
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=0, pin_memory=(device.type=="cuda"))

    # ----- Model / Loss / Optimizer -----
    model = SimpleNetMNIST(p_drop=DROPOUT).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)

    # ----- Train -----
    for ep in range(1, EPOCHS + 1):
        model.train()
        running, seen = 0.0, 0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()
            bs = x.size(0)
            running += loss.item() * bs
            seen += bs

        train_loss = running / max(1, seen)
        print(f"Epoch {ep:02d} | Train Loss {train_loss:.4f}")

if __name__ == "__main__":
    main()
