# pip install torch torchvision

import sys, os
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split
from datetime import datetime

# ===============================
# Reproducibility (optional but helpful)
# ===============================
SEED = 2024
def set_seed(seed=SEED):
    """Fix random seeds to make results reproducible."""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # Deterministic mode can slow down training a bit but helps reproducibility
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# ===============================
# Bigger MLP with two dropout points
# ===============================
class BigMLP(nn.Module):
    """
    A larger MLP to intentionally overfit on a small training subset,
    so that dropout can show generalization benefits.
    """
    def __init__(self, use_dropout=False, p=0.5):
        super().__init__()
        self.use_dropout = use_dropout
        self.fc1 = nn.Linear(28*28, 1024)
        self.fc2 = nn.Linear(1024, 512)
        self.fc3 = nn.Linear(512, 10)
        self.drop1 = nn.Dropout(p)
        self.drop2 = nn.Dropout(p)

    def forward(self, x):
        x = x.view(x.size(0), -1)          # flatten [B,1,28,28] -> [B,784]
        x = F.relu(self.fc1(x))
        if self.use_dropout:
            x = self.drop1(x)              # active only in model.train()
        x = F.relu(self.fc2(x))
        if self.use_dropout:
            x = self.drop2(x)              # active only in model.train()
        x = self.fc3(x)
        return x

# ===============================
# Cross-platform DataLoader setup
# ===============================
def suggest_loader_params(device: str):
    """
    Choose num_workers / pin_memory by OS and device.
    - Windows: use num_workers=0 for safety (spawn)
    - Linux/macOS: you can increase workers; 2~4 is common
    """
    is_windows = os.name == "nt" or sys.platform.startswith("win")
    if is_windows:
        num_workers = 0
    else:
        num_workers = 4  # adjust up/down depending on your CPU
    pin_memory = (device == "cuda")
    return num_workers, pin_memory

def get_loaders_small(batch_size=128, n_train=5000, device="cpu"):
    """
    Returns train/test loaders, but only uses n_train samples from the original 60k
    to make overfitting easier so dropout effect is more visible.
    """
    tfm = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))  # MNIST mean/std
    ])
    full_train = datasets.MNIST("./data", train=True, download=True, transform=tfm)
    test_ds    = datasets.MNIST("./data", train=False, download=True, transform=tfm)

    # Keep only n_train samples for training; drop the rest
    n_total = len(full_train)
    n_rest  = max(0, n_total - n_train)
    train_small, _ = random_split(
        full_train,
        [n_train, n_rest],
        generator=torch.Generator().manual_seed(SEED)  # so the subset is stable
    )

    num_workers, pin_memory = suggest_loader_params(device)
    train_loader = DataLoader(
        train_small, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=pin_memory
    )
    test_loader = DataLoader(
        test_ds, batch_size=512, shuffle=False,
        num_workers=num_workers, pin_memory=pin_memory
    )
    return train_loader, test_loader

# ===============================
# Train / Eval loops
# ===============================
def train_one(model, optimizer, loader, device):
    model.train()
    total = correct = 0
    loss_sum = 0.0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        logits = model(x)
        loss = F.cross_entropy(logits, y)
        loss.backward()
        optimizer.step()

        loss_sum += loss.item() * x.size(0)
        pred = logits.argmax(1)
        correct += (pred == y).sum().item()
        total += x.size(0)
    return loss_sum/total, correct/total

@torch.no_grad()
def test_one(model, loader, device):
    model.eval()
    total = correct = 0
    loss_sum = 0.0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        loss = F.cross_entropy(logits, y)
        loss_sum += loss.item() * x.size(0)
        pred = logits.argmax(1)
        correct += (pred == y).sum().item()
        total += x.size(0)
    acc = correct/total
    err = 1 - acc
    return loss_sum/total, acc, err

# ===============================
# Runner
# ===============================
def run(use_dropout=False, p=0.5, epochs=20, lr=1e-3, device="cpu", n_train=5000):
    """
    Trains BigMLP on a small MNIST subset to induce overfitting
    and returns test error.
    """
    model = BigMLP(use_dropout=use_dropout, p=p).to(device)
    # Keep weight_decay=0 so we isolate dropout effect
    opt = optim.Adam(model.parameters(), lr=lr, weight_decay=0.0)

    train_loader, test_loader = get_loaders_small(
        batch_size=128, n_train=n_train, device=device
    )

    for ep in range(1, epochs+1):
        tr_loss, tr_acc = train_one(model, opt, train_loader, device)
        # Periodically check generalization
        if ep % 5 == 0 or ep == 1:
            te_loss, te_acc, te_err = test_one(model, test_loader, device)
            print(f"{'[Dropout]' if use_dropout else '[NoDrop]'} "
                  f"Epoch {ep:02d}: train_loss={tr_loss:.4f} acc={tr_acc:.4f} | test_err={te_err:.4f}")

    te_loss, te_acc, te_err = test_one(model, test_loader, device)
    print(f"{'[Dropout]' if use_dropout else '[NoDrop]'} FINAL: "
          f"test_loss={te_loss:.4f} acc={te_acc:.4f} ERROR={te_err:.4f}")
    return te_err

# ===============================
# Main (Windows requires the guard)
# ===============================
def main():
    set_seed()  # optional but recommended for fair comparison
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[{datetime.now().strftime('%H:%M:%S')}] device: {device} | OS: {sys.platform}")

    # Baseline: no dropout
    err_nodrop = run(use_dropout=False, epochs=20, device=device, n_train=5000)

    # With dropout
    err_drop   = run(use_dropout=True,  p=0.5, epochs=20, device=device, n_train=5000)

    print("\n=== Summary ===")
    print(f"No Dropout  Test Error: {err_nodrop:.4f}")
    print(f"With Dropout Test Error: {err_drop:.4f}")

if __name__ == "__main__":
    # On Windows, keeping the guard avoids multiprocessing issues with DataLoader.
    # If you really want to use multiple workers on Windows, you can also:
    #   import torch.multiprocessing as mp
    #   mp.set_start_method("spawn", force=True)
    main()
