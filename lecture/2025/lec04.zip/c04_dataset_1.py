class SimpleDataset:
    # A simple dataset that stores a list of items.
    def __init__(self, data):
        self.data = data

    def __len__(self):  # length of dataset
        return len(self.data)

    def __getitem__(self, idx):  # indexing
        return self.data[idx]

    def __iter__(self):  # makes the class iterable
        self._i = 0
        return self

    def __next__(self):  # iteration logic
        if self._i < len(self.data):
            item = self.data[self._i]
            self._i += 1
            return item
        raise StopIteration

# Dataset usage
dataset = SimpleDataset([10, 20, 30])
print("Dataset length:", len(dataset))
print("Index 1:", dataset[1])
for item in dataset:
    print("Iter item:", item)