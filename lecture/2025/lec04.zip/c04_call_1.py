class Dog:
    def __call__(sef):
        print('mung mung')

my_dog = Dog()
my_dog()

class Cat:
    def __call__(self, num):
        print('ya-ong ' * num)

my_cat = Cat()
my_cat(3)