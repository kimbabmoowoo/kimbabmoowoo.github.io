class MyContext:
    def __enter__(self):
        print("--- enter ---")
        return "Resource"

    def __exit__(self, exc_type, exc_val, exc_tb):
        print("--- exit ---")
        print("exc_type:", exc_type)
        print("exc_val :", exc_val)
        print("exc_tb  :", exc_tb)
        return True  # suppress exception if any

# Case 1: No exception
# with MyContext() as res:
#     print("Using:", res)

# Case 2: With exception
with MyContext() as res:
    print("About to divide by zero...")
    1 / 0   # ZeroDivisionError raised inside context