class Vector2D:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __sub__(self, other):  # vector subtraction
        return Vector2D(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar):  # scalar multiplication
        return Vector2D(self.x * scalar, self.y * scalar)

    def __matmul__(self, other):  # dot product
        return self.x * other.x + self.y * other.y

    def __str__(self):  # user-friendly string
        return f"({self.x}, {self.y})"

# Vector2D usage
v1, v2 = Vector2D(2, 3), Vector2D(1, 1)

b = v1 - v2
c = v1 * 2  # in this implementation, v1 * v2 causes error 
d = v1 @ v2

print(b,c,d)    
