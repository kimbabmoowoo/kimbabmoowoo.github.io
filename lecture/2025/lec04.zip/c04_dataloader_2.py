import torch
from torch.utils.data import Dataset, DataLoader, random_split

# 1. Define a simple Dataset class
class SimpleDataset(Dataset):
    def __init__(self, data):
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return torch.tensor(self.data[idx], dtype=torch.float32)


# 2. Prepare the data
my_data = list(range(100))  # numbers 0 to 99
simple_dataset = SimpleDataset(my_data)

# 3. Split into train, validation, and test sets
train_size = int(0.7 * len(simple_dataset))   # 70%
val_size   = int(0.2 * len(simple_dataset))   # 20%
test_size  = len(simple_dataset) - train_size - val_size  # 10%

train_set, val_set, test_set = random_split(simple_dataset, [train_size, val_size, test_size])

# 4. Create DataLoaders
train_loader = DataLoader(train_set, batch_size=8, shuffle=True)
val_loader   = DataLoader(val_set, batch_size=8, shuffle=False)
test_loader  = DataLoader(test_set, batch_size=8, shuffle=False)

# 5. Example usage
if __name__ == '__main__':
    print(f"Dataset sizes -> Train: {len(train_set)}, Val: {len(val_set)}, Test: {len(test_set)}")

    for i, batch in enumerate(train_loader):
        print(f"Train Batch {i+1}: {batch.tolist()}")
        if i >= 2:
            break
