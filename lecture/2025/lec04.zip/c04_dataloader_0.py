# dataloader_minimal.py
import os, platform, torch
from torch.utils.data import TensorDataset, DataLoader

def choose_num_workers():
    """Pick a reasonable number of workers based on CPU count"""
    cpu = os.cpu_count() or 2
    return max(1, min(8, cpu - 1))

def make_loader(batch_size=64, num_workers=None):
    """Build a DataLoader with dummy data"""
    if num_workers is None:
        num_workers = choose_num_workers()
    pin = torch.cuda.is_available()

    # Dummy dataset: 1024 samples, 20 features each, binary labels
    X = torch.randn(1024, 20)
    y = torch.randint(0, 2, (1024,))
    ds = TensorDataset(X, y)

    kwargs = dict(
        dataset=ds, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=pin,
        persistent_workers=(num_workers > 0),
    )
    if num_workers > 0:
        kwargs["prefetch_factor"] = 2  # only valid when num_workers > 0
    return DataLoader(**kwargs)

def main():
    # Force "spawn" start method: safe for both Windows and Ubuntu
    try:
        torch.multiprocessing.set_start_method("spawn", force=True)
    except RuntimeError:
        pass  # already set

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"OS={platform.system()} | torch={torch.__version__} | device={device}")

    # 1) Debug run with num_workers=0 (catches any dataset errors clearly)
    dl0 = make_loader(batch_size=32, num_workers=0)
    next(iter(dl0))  # just one batch

    # 2) Actual run with parallel workers
    dl = make_loader(batch_size=64)  # auto-selects good num_workers
    for xb, yb in dl:
        xb = xb.to(device, non_blocking=True)
        yb = yb.to(device, non_blocking=True)
        # Here you would normally train your model
        print(xb.shape, yb.shape)  # print one batch shape as example
        break

if __name__ == "__main__":
    main()
