import os

# Example: we want to work with a folder for MNIST dataset
base_dir = "."        # current directory
sub_dir = "data"
dataset = "MNIST"
raw_dir = "raw"

# os.path.join() combines parts into a valid path for your OS
# On Windows -> ".\\data\\MNIST\\raw"
# On Linux/Ubuntu/Mac -> "./data/MNIST/raw"
target_path = os.path.join(base_dir, sub_dir, dataset, raw_dir)
print("Joined path:", target_path)

# os.path.exists() checks whether the given path already exists
if os.path.exists(target_path):
    print("OK. The folder already exists:", target_path)
else:
    print("Not OK. The folder does NOT exist, creating it now...")
    os.makedirs(target_path, exist_ok=True)   # safe folder creation
    print("Folder created:", target_path)
