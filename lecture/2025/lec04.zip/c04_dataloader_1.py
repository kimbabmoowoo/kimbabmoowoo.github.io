import torch
from torch.utils.data import Dataset, DataLoader

# 1. Define a simple Dataset class
class SimpleDataset(Dataset):
    def __init__(self, data):
        # data (list): Data as a list of numbers.       
        self.data = data

    def __len__(self):
        # Return the total number of data points in the dataset
        return len(self.data)

    def __getitem__(self, idx):
        # Return the data point at the given index
        sample = self.data[idx]
        
        # Convert to a PyTorch tensor
        return torch.tensor(sample, dtype=torch.float32)

# 2. Prepare the data
# For this example, we use a list of numbers from 0 to 99.
my_data = list(range(100))

# 3. Create and use the Dataset and DataLoader
if __name__ == '__main__':
    
    # Create a Dataset instance
    simple_dataset = SimpleDataset(my_data)

    # Create a DataLoader instance
    # Set the batch size to 8 and shuffle the data.
    data_loader = DataLoader(
        dataset=simple_dataset,
        batch_size=8,
        shuffle=True,
    )
    
    # Use the DataLoader to load data
    print(f"Total number of data points: {len(simple_dataset)}")
    print(f"Total number of batches: {len(data_loader)}")
    print(f"Batch size: {data_loader.batch_size}\n")
    
    for i, batch in enumerate(data_loader):
        print(f"--- Batch {i+1} ---")
        print(f"Batch tensor size: {batch.shape}")
        print(f"Data: {batch.tolist()}")
        
        # Print only the first 3 batches and then stop
        if i >= 2:
            break

    print("\nData loading complete!")