import torch

# Example hidden layer: batch of 32 samples, each with 128 features
x = torch.randn(32, 128)

eps = 1e-5  # small constant for numerical stability

# -------------------------
# Batch Normalization (manual)
# -------------------------
mean_bn = x.mean(dim=0, keepdim=True)          # [1, 128]
var_bn = x.var(dim=0, unbiased=False, keepdim=True)  # [1, 128]
x_bn = (x - mean_bn) / torch.sqrt(var_bn + eps)

# learnable parameters (gamma, beta)
gamma_bn = torch.ones(1, 128)
beta_bn = torch.zeros(1, 128)
out_bn = gamma_bn * x_bn + beta_bn

print("BN output shape:", out_bn.shape)

# -------------------------
# Layer Normalization (manual)
# -------------------------
mean_ln = x.mean(dim=1, keepdim=True)          # [32, 1]
var_ln = x.var(dim=1, unbiased=False, keepdim=True)  # [32, 1]
x_ln = (x - mean_ln) / torch.sqrt(var_ln + eps)

# learnable parameters (gamma, beta)
gamma_ln = torch.ones(1, 128)   # broadcast across batch
beta_ln = torch.zeros(1, 128)
out_ln = gamma_ln * x_ln + beta_ln

print("LN output shape:", out_ln.shape)
