import random
from collections import Counter

import torch
import torch.nn as nn
import torch.nn.functional as F


# =========================
# 1. Simple corpus
# =========================
# We focus on four words: cat, dog, milk, water
corpus = [
    "the cat drinks milk",
    "the dog drinks water",
    "the cat likes milk",
    "the dog likes water",
]


# =========================
# 2. Build vocabulary
# =========================
tokens = " ".join(corpus).split()
vocab = sorted(set(tokens))  # e.g. ['cat', 'dog', 'drinks', 'likes', 'milk', 'the', 'water']

word2id = {w: i for i, w in enumerate(vocab)}
id2word = {i: w for w, i in word2id.items()}
vocab_size = len(vocab)

print("word2id:", word2id)
print("id2word:", id2word)

# print("Vocab:", vocab)
# print("Vocab size:", vocab_size)

# Convert each sentence into a list of word IDs
corpus_ids = [[word2id[w] for w in sent.split()] for sent in corpus]
print(corpus_ids)

# =========================
# 3. Build Skip-gram (center, context) pairs
# =========================
def make_skipgram_pairs(corpus_ids, window_size=1):
    """
    For each word in each sentence, create pairs:
    (center_word, context_word) within a given window size.
    """
    pairs = []
    for sent in corpus_ids:
        for i, center in enumerate(sent):
            # context window: [i - window_size, ..., i + window_size]
            for j in range(max(0, i - window_size), min(len(sent), i + window_size + 1)):
                if j == i:
                    continue  # skip the center word itself
                context = sent[j]
                pairs.append((center, context))
    return pairs


pairs = make_skipgram_pairs(corpus_ids, window_size=1)
# print("Skip-gram pairs (id):", pairs)
# print("Skip-gram pairs (words):", [(id2word[c], id2word[o]) for c, o in pairs])

# =========================
# 4. Negative sampling helper
# =========================
# Simple negative sampling: sample words according to frequency ^ 0.75
freq = Counter([w for sent in corpus_ids for w in sent])
#print(freq)

# Build a list of word indices for sampling, weighted by freq^0.75
neg_sampling_table = []
for wid, f in freq.items():
    weight = f ** 0.75
    neg_sampling_table.extend([wid] * int(weight * 10))  # scale up for more resolution

# print("freq.items(): ", freq.items())
# print("neg_sampling_table: ", neg_sampling_table)

def sample_negative(batch_pos_ids, num_negatives):
    """
    For each positive target id in batch_pos_ids,
    sample 'num_negatives' different negative word ids (not equal to the positive one).
    Returns a tensor of shape (batch_size, num_negatives).
    """
    batch_neg = []

    for pos_id in batch_pos_ids:
        negatives = []
        while len(negatives) < num_negatives:
            cand = random.choice(neg_sampling_table)
            if cand != pos_id:
                negatives.append(cand)
        batch_neg.append(negatives)
    return torch.tensor(batch_neg, dtype=torch.long)


# =========================
# 5. Word2Vec Skip-gram model with negative sampling
# =========================
class Word2VecSkipGram(nn.Module):
    def __init__(self, vocab_size, embed_dim):
        super().__init__()
        # Embeddings for center words
        self.in_embed = nn.Embedding(vocab_size, embed_dim)
        # Embeddings for context words
        self.out_embed = nn.Embedding(vocab_size, embed_dim)

        # Initialize embeddings (optional but common)
        nn.init.uniform_(self.in_embed.weight, -0.5 / embed_dim, 0.5 / embed_dim)
        nn.init.uniform_(self.out_embed.weight, -0.5 / embed_dim, 0.5 / embed_dim)

    def forward(self, center_ids, pos_ids, neg_ids):
        """
        center_ids: (batch,)
        pos_ids:    (batch,)
        neg_ids:    (batch, K)   where K = # negative samples
        """
        # Lookup embeddings
        center_embed = self.in_embed(center_ids)       # (batch, D)
        pos_embed    = self.out_embed(pos_ids)         # (batch, D)
        neg_embed    = self.out_embed(neg_ids)         # (batch, K, D)

        # Positive score: dot(center, pos)
        pos_score = torch.sum(center_embed * pos_embed, dim=1)  # (batch,)
        pos_loss = F.logsigmoid(pos_score)                      # (batch,)

        # Negative score: dot(center, neg) for each negative
        # center_embed: (batch, D) -> (batch, D, 1)
        # neg_embed: (batch, K, D)
        neg_score = torch.bmm(neg_embed, center_embed.unsqueeze(2)).squeeze(2)  # (batch, K)
        neg_loss = F.logsigmoid(-neg_score).sum(dim=1)                          # (batch,)

        # We want to MAXIMIZE pos_loss + neg_loss, so MINIMIZE negative of that
        loss = -(pos_loss + neg_loss).mean()
        return loss


# =========================
# 6. Training loop
# =========================
embed_dim = 8          # embedding dimension (can try 2, 8, 16, ...)
num_negatives = 4      # number of negative samples
batch_size = min(8, len(pairs))
num_epochs = 2000      # training epochs
lr = 0.01

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = Word2VecSkipGram(vocab_size, embed_dim).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=lr)

# Convert all pairs to tensors for easier batching
all_centers = torch.tensor([c for c, o in pairs], dtype=torch.long)
all_contexts = torch.tensor([o for c, o in pairs], dtype=torch.long)

for epoch in range(1, num_epochs + 1):
    # Sample a random mini-batch
    indices = torch.randint(0, len(pairs), (batch_size,))
    batch_centers = all_centers[indices].to(device)
    batch_pos     = all_contexts[indices].to(device)
    batch_neg     = sample_negative(batch_pos.tolist(), num_negatives).to(device)

    # Forward + Backward
    loss = model(batch_centers, batch_pos, batch_neg)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    if epoch % 200 == 0:
        print(f"Epoch {epoch}/{num_epochs} - Loss: {loss.item():.4f}")

# =========================
# 7. Inspect learned embeddings
# =========================
print("\nLearned input embeddings (in_embed):")
for w in ["cat", "dog", "milk", "water"]:
    wid = word2id[w]
    vec = model.in_embed.weight[wid].detach().cpu().numpy()
    print(f"{w:>6} → {vec}")