from collections import Counter

corpus_ids = [[5, 0, 2, 4], [5, 1, 2, 6], [5, 0, 3, 4], [5, 1, 3, 6]]

words = []

for sent in corpus_ids:
    for w in sent:
        words.append(w)

print("words: ", words)

# Count how many times each word ID appears
freq_1 = Counter(words)
print("freq_1: ", freq_1)

# nested list comprehension
freq_2 = Counter([w for sent in corpus_ids for w in sent])
print("freq_2: ", freq_2)

print(type(freq_2.items()))
print("freq_2.items():", freq_2.items())
