# Softmax classification (2 -> 3 -> 4) with ReLU hidden, fixed init, and backprop in PyTorch

import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

torch.set_printoptions(precision=6, sci_mode=False)

# ---- 1) Model ----
class MyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2, 3, bias=True)  # input(2) -> hidden(3)
        self.fc2 = nn.Linear(3, 4, bias=True)  # hidden(3) -> output(4)  (logits)
        self.reset_to_given_values()

    def reset_to_given_values(self):
        W_ih = torch.tensor([[0.1, 0.2, 0.3],
                             [0.4, 0.5, 0.6]], dtype=torch.float32)  # (2x3)
        B_h  = torch.tensor([0.2, 0.4, 0.6], dtype=torch.float32)     # (3,)
        W_ho = torch.tensor([[0.7, 0.8, 0.5, 0.2],
                             [0.9, 0.1, 0.4, 0.3],
                             [0.2, 0.3, 0.6, 0.7]], dtype=torch.float32)  # (3x4)
        B_o  = torch.tensor([0.5, 0.7, 0.2, 0.1], dtype=torch.float32)     # (4,)

        with torch.no_grad():
            # nn.Linear stores weight as (out_features, in_features)
            self.fc1.weight.copy_(W_ih.t())  # (3,2)
            self.fc1.bias.copy_(B_h)
            self.fc2.weight.copy_(W_ho.t())  # (4,3)
            self.fc2.bias.copy_(B_o)

    def forward(self, x):
        # x: (N,2)
        h = torch.relu(self.fc1(x))
        logits = self.fc2(h)   # raw scores for CrossEntropyLoss
        return logits

# ---- 2) Data / Loss / Optimizer ----
model = MyModel()

# Batch of one sample to play nicely with CrossEntropyLoss
x = torch.tensor([[0.5, 0.8]], dtype=torch.float32)  # (1,2)
target_index = torch.tensor([3], dtype=torch.long)   # (1,)

criterion = nn.CrossEntropyLoss(reduction='mean')  # applies log-softmax + NLL
learning_rate = 0.10
optimizer = optim.SGD(model.parameters(), lr=learning_rate)

# ---- 3) print parameters ----
def print_params(step, mdl):
    with torch.no_grad():
        Wih = mdl.fc1.weight.t()
        Bh  = mdl.fc1.bias
        Who = mdl.fc2.weight.t()
        Bo  = mdl.fc2.bias
        print(f"\n[After step {step}]")
        print("W_ih =\n", Wih.numpy())
        print("B_h  = ", Bh.numpy())
        print("W_ho =\n", Who.numpy())
        print("B_o  = ", Bo.numpy())

# Helper to view softmax probs
def softmax_probs(logits):
    return torch.softmax(logits, dim=1)  # softmax per row (across classes) --> rows sum to 1

# ---- 4) Training loop with loss tracking ----
losses = []

for step in range(1, 21):  # 20 steps to see the curve
    optimizer.zero_grad()
    logits = model(x)                  # (1,4)
    probs  = softmax_probs(logits)     # for inspection only
    loss   = criterion(logits, target_index)  # CE on logits
    loss.backward()

    # (Optional) On step 1, verify q_o = probs - one_hot equals grad wrt output bias
    if step == 1:
        with torch.no_grad():
            one_hot = torch.zeros_like(probs)
            one_hot[0, target_index.item()] = 1.0
            q_o = probs - one_hot  # shape (1,4)
            print("\n[Step 1: gradient check at output layer]")
            print("logits =", logits.detach().squeeze(0))
            print("probs  =", probs.detach().squeeze(0))
            print("q_o (= probs - one_hot)        =", q_o.squeeze(0))
            print("grad wrt output bias (fc2.bias)=", model.fc2.bias.grad)

    optimizer.step()

    losses.append(loss.item())
    print(f"step {step} | loss = {loss.item():.6f} | probs = {probs.detach().numpy().round(6)}")

    if step % 5 == 0:
        print_params(step, model)

# ---- 5) Plot loss curve ----
plt.figure(figsize=(6,4))
plt.plot(range(1, len(losses)+1), losses, marker='o')
plt.xlabel("Step")
plt.ylabel("Loss (CrossEntropy)")
plt.title("Loss Curve during Training (Softmax + CE)")
plt.grid(True)
plt.show()
