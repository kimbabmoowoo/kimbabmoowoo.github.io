import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# ---- 1) Model ----
class MyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2, 3)  # input(2) -> hidden(3)
        self.fc2 = nn.Linear(3, 2)  # hidden(3) -> output(2)

    def forward(self, x):
        x = torch.relu(self.fc1(x))  # ReLU only in the hidden layer
        x = self.fc2(x)              # No activation on the output layer
        return x

# ---- 2) Data / Loss / Optimizer ----
model = MyModel()
x = torch.tensor([0.5, 0.8], dtype=torch.float32).unsqueeze(0)  # [1, 2]
t = torch.tensor([0.1, 0.9], dtype=torch.float32).unsqueeze(0)  # [1, 2]

criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)  # smaller LR for stability

# ---- 3) Training loop with loss tracking ----
losses = []
for step in range(1, 101):  # 100 steps for clearer trend
    optimizer.zero_grad()
    y = model(x)
    loss = criterion(y, t)
    loss.backward()
    optimizer.step()

    losses.append(loss.item())
    if step % 10 == 0:
        print(f"step {step:3d} | loss = {loss.item():.6f}")

# ---- 4) Plot loss curve ----
plt.figure(figsize=(6,4))
plt.plot(range(1, len(losses)+1), losses, marker='o')
plt.xlabel("Step")
plt.ylabel("Loss (MSE)")
plt.title("Loss Curve during Training")
plt.grid(True)
plt.show()
