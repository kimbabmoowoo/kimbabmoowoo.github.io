import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# ---- 1) Model ----
class myModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2, 3, bias=True)  # input(2) -> hidden(3)
        self.fc2 = nn.Linear(3, 2, bias=True)  # hidden(3) -> output(2)
        self.reset_to_given_values()

    def reset_to_given_values(self):
        # Given matrices in the document
        W_ih = torch.tensor([[0.1, 0.2, 0.3],
                             [0.4, 0.5, 0.6]], dtype=torch.float32)
        B_h  = torch.tensor([0.2, 0.4, 0.6], dtype=torch.float32)
        W_ho = torch.tensor([[0.7, 0.8],
                             [0.9, 0.1],
                             [0.2, 0.3]], dtype=torch.float32)
        B_o  = torch.tensor([0.5, 0.7], dtype=torch.float32)

        with torch.no_grad():
            self.fc1.weight.copy_(W_ih.t())  # (3,2)
            self.fc1.bias.copy_(B_h)
            self.fc2.weight.copy_(W_ho.t())  # (2,3)
            self.fc2.bias.copy_(B_o)

    def forward(self, x):
        x = torch.relu(self.fc1(x))  # hidden layer only
        x = self.fc2(x)              # output layer: no ReLU
        return x

# ---- 2) Data / Loss / Optimizer ----
model = myModel()
x = torch.tensor([0.5, 0.8], dtype=torch.float32)
t = torch.tensor([0.1, 0.9], dtype=torch.float32)

criterion = nn.MSELoss(reduction='mean')  # default MSE
learning_rate = 0.10
optimizer = optim.SGD(model.parameters(), lr=learning_rate)

# ---- 3) print parameters ----
def print_params(step, mdl):
    with torch.no_grad():
        Wih = mdl.fc1.weight.t()
        Bh  = mdl.fc1.bias
        Who = mdl.fc2.weight.t()
        Bo  = mdl.fc2.bias
        print(f"\n[After step {step}]")
        print("W_ih =\n", Wih.numpy())
        print("B_h  = ", Bh.numpy())
        print("W_ho =\n", Who.numpy())
        print("B_o  = ", Bo.numpy())

# ---- 4) Training loop with loss tracking ----
losses = []

for step in range(1, 21):  # 20 steps to see the curve
    optimizer.zero_grad()
    y = model(x)
    loss = criterion(y, t)
    loss.backward()
    optimizer.step()

    losses.append(loss.item())  # record loss
    print(f"step {step} | loss = {loss.item():.6f}")

    if step % 5 == 0:
        print_params(step, model)

# ---- 5) Plot loss curve ----
plt.figure(figsize=(6,4))
plt.plot(range(1, len(losses)+1), losses, marker='o')
plt.xlabel("Step")
plt.ylabel("Loss (MSE)")
plt.title("Loss Curve during Training")
plt.grid(True)
plt.show()
