import torch
import matplotlib.pyplot as plt
import torch.nn as nn

# Define x values using PyTorch
x = torch.linspace(-5, 5, 100)

# Define activation functions using PyTorch
sigmoid = torch.sigmoid(x)
tanh = torch.tanh(x)
relu = torch.relu(x)
gelu_approx = nn.GELU(approximate='tanh')

# Plot with Matplotlib
plt.figure(figsize=(10,6))

#plt.plot(x.numpy(), sigmoid.numpy(), label=r"$\sigma(x)$: Sigmoid", color="red")
#plt.plot(x.numpy(), tanh.numpy(), label=r"$\tanh(x)$: Tanh", color="green")
#plt.plot(x.numpy(), relu.numpy(), label=r"$ReLU(x)$", color="blue")
plt.plot(x.numpy(), gelu_approx(x), label=r"$ReLU(x)$", color="blue")

#plt.title("Activation Function: Sigmoid", fontsize=14)
#plt.title("Activation Function: Tanh(x)", fontsize=14)
#plt.title("Activation Function: ReLU(x)", fontsize=14)
plt.title("Activation Function: GELU(x)", fontsize=14)
plt.xlabel("x", fontsize=12)
plt.ylabel("f(x)", fontsize=12)

# Draw reference lines
plt.axhline(0, color='black', linewidth=0.8, linestyle='--')
plt.axvline(0, color='black', linewidth=0.8, linestyle='--')

# Legend and grid
plt.legend(fontsize=12)
plt.grid(True, linestyle="--", alpha=0.6)

plt.show()
