# download_cifar10.py
import torchvision.datasets as datasets

# Download CIFAR-10 (train and test) into the "data" folder
train_dataset = datasets.CIFAR10(root="./data", train=True, download=True)
test_dataset  = datasets.CIFAR10(root="./data", train=False, download=True)

print("CIFAR-10 dataset has been downloaded !")
print(f"Training set size: {len(train_dataset)}")
print(f"Test set size: {len(test_dataset)}")