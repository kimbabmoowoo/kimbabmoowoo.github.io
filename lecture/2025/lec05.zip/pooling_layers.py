import torch
import torch.nn as nn

# 1D Max Pooling =================================================
x = torch.randn(1, 1, 8)  # [batch=1, channel=1, length=8]
pool1d = nn.MaxPool1d(kernel_size=2, stride=2)
print(pool1d(x).shape)  #  [1, 1, 4]

# 2D Max Pooling =================================================
x = torch.randn(1, 1, 8, 4) # [batch, channel, height, width]
pool2d = nn.MaxPool2d(kernel_size=2, stride=2)
print(pool2d(x).shape)  #  [1, 1, 4, 2]

# 3D Max Pooling =================================================
x = torch.randn(1, 1, 4, 8, 4)  # [batch, channel, depth, height, width]
pool3d = nn.MaxPool3d(kernel_size=2, stride=2)
print(pool3d(x).shape)  #  [1, 1, 2, 4, 2]