import torch
import torch.nn as nn

# 1D Conv =================================================
x = torch.randn(1, 3, 100)  # batch=1, channels=3, length=100

conv1d = nn.Conv1d(in_channels=3, out_channels=6, kernel_size=5, stride=1, padding=2)
y = conv1d(x)
print(y.shape)  # [1, 6, 100]

# 2D Conv =================================================
x = torch.randn(1, 3, 64, 64)  # batch=1, RGB image 64x64

conv2d = nn.Conv2d(in_channels=3, out_channels=16, kernel_size=3, stride=1, padding=1)
y = conv2d(x)
print(y.shape)  # [1, 16, 64, 64]

# 3D Conv =================================================
x = torch.randn(1, 3, 16, 64, 64)  # 16 frames of 64x64 RGB video

conv3d = nn.Conv3d(in_channels=3, out_channels=8, kernel_size=3, stride=1, padding=1)
y = conv3d(x)
print(y.shape)  # [1, 8, 16, 64, 64]