import torch
import torch.nn as nn

# Create a simple 4x4 input tensor (1 channel, batch size = 1)
x = torch.tensor([[
    [[2.0, 3.0, 2.0, 0.0],
     [5.0, -2.0, 2.0, 8.0],
     [-1.0, -6.0, 7.0, 3.0],
     [-4.0, -5.0, 4.0, 2.0]]
]])

# Define pooling layers
max_pool = nn.MaxPool2d(kernel_size=2, stride=2)
avg_pool = nn.AvgPool2d(kernel_size=2, stride=2)

# Apply pooling
max_out = max_pool(x)
avg_out = avg_pool(x)

print("\nMax Pooling Output:")
print(max_out)

print("\nAverage Pooling Output:")
print(avg_out)

print(x.shape, max_out.shape) # [ batch size, number of channels, height, width ]
