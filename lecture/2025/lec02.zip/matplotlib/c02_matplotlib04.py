import matplotlib.pyplot as plt
import numpy as np

# Sample data
x = np.arange(5)
y = np.random.randint(1, 10, size=5)
scatter_x = np.random.rand(50)
scatter_y = np.random.rand(50)
hist_data = np.random.randn(1000)

# Create figure with 3 subplots
fig, axes = plt.subplots(1, 3, figsize=(12, 4))

# Bar chart
axes[0].bar(x, y, color='skyblue')
axes[0].set_title("Bar Chart")

# Scatter plot
axes[1].scatter(scatter_x, scatter_y, c='red', alpha=0.6)
axes[1].set_title("Scatter Plot")

# Histogram
axes[2].hist(hist_data, bins=20, color='green', alpha=0.7)
axes[2].set_title("Histogram")

plt.tight_layout()
#plt.show()

print(y)