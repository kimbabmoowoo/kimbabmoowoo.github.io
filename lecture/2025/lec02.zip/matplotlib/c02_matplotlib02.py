import numpy as np
import matplotlib.pyplot as plt

# Create data
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)

# Plot both
plt.plot(x, y1, label="sin(x)", color="red")
plt.plot(x, y2, label="cos(x)", color="green")

plt.xlabel("x value")
plt.ylabel("y value")
plt.title("Sine and Cosine Functions")
#plt.legend()
plt.show()
