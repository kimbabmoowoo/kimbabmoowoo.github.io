import numpy as np
import matplotlib.pyplot as plt

# Create data with NumPy
x = np.linspace(0, 10, 100)   # 100 points from 0 to 10
y = 2 * x                     # y = 2x

plt.plot(x, y)

plt.title("Draw a Line with NumPy")
plt.xlabel("X values")
plt.ylabel("Y values")

plt.show()