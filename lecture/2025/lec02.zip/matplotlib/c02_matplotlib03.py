import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = 2 * x

# fig = whole figure (canvas), axes = subplots (small plots inside the figure)
# 1 row, 2 columns → two plots side by side
# figsize=(10, 4) → width=10 inches, height=4 inches
fig, axes = plt.subplots(1, 2, figsize=(10, 4))

# Left subplot
axes[0].plot(x, y1, color="blue")
axes[0].set_title("Sine Function")
axes[0].set_xlabel("x")
axes[0].set_ylabel("sin(x)")

# Right subplot
axes[1].plot(x, y2, color="red")
axes[1].set_title("Linear Function")
axes[1].set_xlabel("x")
axes[1].set_ylabel("2*x")

plt.tight_layout()  # auto-adjust spacing between subplots
plt.show()