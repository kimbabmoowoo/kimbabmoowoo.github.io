import numpy as np
import pandas as pd

# Create a Series from a NumPy array
data = np.array([10, 20, 30, 40])
s = pd.Series(data, index=["A", "B", "C", "D"])
# print(s)
# print(s.values)

# Create a DataFrame from a dictionary
data = {
    "Category": ["dog", "cat", "goat"],
    "Age": [3, 2, 8],
    "weight": [15, 10, 35]
}
df = pd.DataFrame(data)
# print(df)
# print(df["Age"])
#print(df["Age"].mean())  # Average of Age

#print(df.iloc[0])        # first row
#print(df.iloc[1])        # second row
print(df.iloc[:,0])      # all rows, first column