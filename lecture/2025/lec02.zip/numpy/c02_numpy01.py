import numpy as np

# Create arrays
a = np.array([1, 2, 3])
b = np.array([[1, 2, 3],
              [4, 5, 6]])

print(a)               # [1 2 3]
print(b)               # 2 rows, 3 cols

print(a.ndim)          # number of axes: 1
print(b.ndim)          # number of axes: 2
print(b.shape)         # (2, 3) -> 2 rows, 3 columns
print(b.dtype)         # data type (e.g., int64 or int32)

# Make arrays of zeros/ones or a range
z = np.zeros((2, 3))           # shape 2x3, all zeros (float)
o = np.ones((3, 2), dtype=int) # shape 3x2, all ones (int)
r = np.arange(0, 10, 2)        # [0  2  4  6  8]
lin = np.linspace(0, 1, 5)     # [0.  0.25   0.5  0.75   1. ]
print(z, o, r, lin, sep="\n")
