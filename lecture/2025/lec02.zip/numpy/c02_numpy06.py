import numpy as np

# [1] reshape(), rave() ==============================================
C = np.arange(12)             # [0..11]
# print(C.reshape(3, 4))        # shape (3,4)
# print(C.reshape(-1, 6))       # -1 lets NumPy infer -> (2,6)
# print(C.ravel())              # flat view if possible

# [2] np.array([1., 2.])  ==============================================
b = np.array([1., 2.])   # shape: (2,)  ← neither row nor column

# row = b[None, :]    # shape: (1, 2)  ← row vector        
# col = b[:, None]    # shape: (2, 1)  ← column vector        

row = b[np.newaxis, :]    # shape: (1, 2)  ← row vector        
col = b[:, np.newaxis]    # shape: (2, 1)  ← column vector  

# Equivalent forms
row2 = b.reshape(1, -1)  # (1, 2)  
col2 = b.reshape(-1, 1)  # (2, 1)  

print(row.shape, col.shape)

# Matrx multiplication
A = np.array([[1., 2.],
              [3., 4.]])

print(b @ A)     # (2,) @ (2,2) → (2,)   (behaves like a row in this context)
# print(A @ b)     # (2,2) @ (2,) → (2,)   (behaves like a column in this context)

# print(row @ A)   # (1,2) @ (2,2) → (1,2)
# print(A @ col)   # (2,2) @ (2,1) → (2,1)

# [3] np.stack() =======================================================
X = np.array([1, 2, 3])
Y = np.array([4, 5, 6])

# print(np.stack([X, Y], axis=0))  # [[1 2 3], [4 5 6]]
# print(np.stack([X, Y], axis=1))  # [[1 4], [2 5], [3 6]]

# print(np.vstack([X, Y]))   # [[1 2 3], [4 5 6]]
# print(np.hstack([X, Y]))   # [1 2 3 4 5 6]

# print(X.shape, Y.shape)

# a = np.stack([X, Y], axis=0)
# b = np.stack([X, Y], axis=1)
# print(a.shape)
# print(b.shape)

# [4] Linear algebra  ====================================================
A = np.array([[2., 1.],
              [1., 3.]])
b = np.array([1., 2.])

# Solve A x = b
x = np.linalg.solve(A, b)
#print("solution:", x)

# Matrix multiply (dot product)
M = np.array([[1, 2],
              [3, 4]])
N = np.array([[10, 20],
              [30, 40]])

# print(M * N)               # caution: element-wise multiplication
# print(M @ N)               # matrix product
# print(np.dot(M, N))        # matrix product (M @ N)

# print(np.linalg.eig(M))    # eigenvalues & eigenvectors