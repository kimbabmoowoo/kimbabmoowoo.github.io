import numpy as np

A = np.array([[1, 2, 3],
              [4, 5, 6]])   # shape (2,3)

d = 10
print(A + d)
# [[11 12 13]
#  [14 15 16]]

print(type(d))
print(type(A+d))

b = np.array([10, 20, 30])  # shape (3,)
print(A + b)
# [[11 22 33]
#  [14 25 36]]

c = np.array([[100],        # shape (2,1)
              [200]])
print(A+ c)
# [[101 102 103]
#  [204 205 206]]

