import numpy as np

# (1) list, for loop  ==============================================================
a = list(range(5))
b = list(range(5))

result = [a[i] + b[i] for i in range(len(a))]  # without vectorization
#print(result)

# (1) numpy 
a = np.arange(5)
b = np.arange(5)

result = a + b   # vectorization
#print(result)

# (2) list, for loop  ==============================================================
numbers = list(range(5))
squared = [x**2 for x in numbers]
#print(squared)

# (2) numpy 
numbers = np.arange(5)
squared = numbers ** 2  # vectorization
print(squared)