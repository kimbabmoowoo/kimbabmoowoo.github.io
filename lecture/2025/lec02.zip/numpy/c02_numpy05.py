import numpy as np

B = np.array([[1, 2, 3],
              [4, 5, 6]])

print(B.sum())            # 21
print(B.mean(), B.min(), B.max())  # 3.5 1 6
print(np.median(B), np.std(B))     # 3.5, standard deviation

print(B.sum(axis=0))      # column sums -> [5 7 9]
print(B.sum(axis=1))      # row sums -> [ 6 15]

# column-wise mean (axis=0)
col_means = B.mean(axis=0)
print("axis=0 (columns) mean:", col_means)   # [2.5 3.5 4.5]

# row-wise mean (axis=1)
row_means = B.mean(axis=1)
print("axis=1 (rows) mean:", row_means)      # [2. 5.]