import torch

# -------------------------
# 1) Toy dataset (1D line)
#    Label = 1 if x > 0, else 0
# -------------------------
N = 200
x = torch.linspace(-2, 2, N).unsqueeze(1)           # shape: (N,1)
y = (x[:,0] > 0).float()                            # step function

# -------------------------
# 2) Logistic regression model
# -------------------------
model = torch.nn.Linear(1, 1)                       # w*x + b
criterion = torch.nn.BCEWithLogitsLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.1)

# -------------------------
# 3) Training
# -------------------------
for step in range(100):
    logits = model(x).squeeze(1)                    # raw scores
    loss = criterion(logits, y)                     # binary CE loss

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    if step % 20 == 0:
        with torch.no_grad():
            preds = (logits > 0).float()            # threshold at 0
            acc = (preds == y).float().mean().item()
        print(f"step={step:3d}  loss={loss.item():.4f}  acc={acc:.3f}")