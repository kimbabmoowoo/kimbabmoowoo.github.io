#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (10) Converting between Numpy and Tensor -----------------------------

import torch
import numpy as np

np_array = np.array([1, 2, 3])

# Numpy -> Tensor
tensor_from_np = torch.from_numpy(np_array)
print("Tensor from numpy:", tensor_from_np)

# Tensor -> Numpy
back_to_np = tensor_from_np.numpy()
print("Back to numpy:", back_to_np)

# =======================================================================
# using GPU
# device (use GPU if available)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
a = torch.tensor([1., 2.], device=device)
b = torch.tensor([1., 2.])
print(a)
print(b)

t = torch.arange(12).view(3, 4)
print("reshaped (3x4):\n", t)
