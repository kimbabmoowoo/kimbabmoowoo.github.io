#  Lecture 02-PyTorch01 
#
#  Simplest Example (1) 
#     Linear regression 
# ======================================

import torch

# Reproducibility
torch.manual_seed(0)

# 1) Ground-truth (random) + data
a_star = torch.randn(1)          # true slope
b_star = torch.randn(1)          # true intercept
N = 200                       
x = torch.linspace(-5, 5, N).unsqueeze(1) # .unsqueeze(1) adds a new dimension at index 1 : making a column vector
noise_std = 0.5
y = a_star * x + b_star + noise_std * torch.randn(N, 1)

# 2) Parameters to learn (scalars with grad)
a = torch.randn(1, requires_grad=True)
b = torch.randn(1, requires_grad=True)

# 3) Optimizer (Adam tends to be steadier than plain SGD here)
#opt = torch.optim.Adam([a, b], lr=0.05)
opt = torch.optim.SGD([a, b], lr=0.05)

# 4) Training loop
for _ in range(3000):            # more steps → steadier convergence
    y_hat = a * x + b
    loss = torch.mean((y_hat - y) ** 2)

    opt.zero_grad()              # clear old gradients
    loss.backward()              # compute ∂L/∂a, ∂L/∂b
    opt.step()                   # update a, b

print(f"True:    a* = {a_star.item():.4f}, b* = {b_star.item():.4f}")
print(f"Learned: a  = {a.item():.4f}, b  = {b.item():.4f}")
print(f"MSE: {loss.item():.4f}")