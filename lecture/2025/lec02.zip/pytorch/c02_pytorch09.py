#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (9) Linear algebra :  PyTorch tensors-----------------------------

import torch

A = torch.tensor([[2., 1.],
                  [1., 3.]])
b = torch.tensor([1., 2.])

# Solve A x = b
x = torch.linalg.solve(A, b)
print("solution:", x)

# Matrix multiply (dot product)
M = torch.tensor([[1, 2],
                  [3, 4]], dtype=torch.float64)
N = torch.tensor([[10, 20],
                  [30, 40]], dtype=torch.float64)

print(M * N)          # element-wise multiplication
print(M @ N)          # matrix product
print(torch.matmul(M, N))  # matrix product (same as @)

# Eigenvalues & eigenvectors
eigvals, eigvecs = torch.linalg.eig(M)
print("eigenvalues:", eigvals)
print("eigenvectors:\n", eigvecs)