#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (2) Indexing & Slicing of PyTorch tensors-----------------------------

import torch

A = torch.tensor([[10, 11, 12],
                  [20, 21, 22],
                  [30, 31, 32]])

print(A[0, 1].item())     # row 0, col 1 -> 11
print(A[1])               # entire row 1 -> tensor([20, 21, 22])
print(A[:, 2])            # entire col 2 -> tensor([12, 22, 32])
print(A[0:2, 1:3])        # rows 0..1, cols 1..2 -> tensor([[11, 12],[21, 22]])

# Boolean indexing (filtering)
mask = (A % 20 == 0)      # True where divisible by 20
print(mask)
print(A[mask])            # tensor([20])