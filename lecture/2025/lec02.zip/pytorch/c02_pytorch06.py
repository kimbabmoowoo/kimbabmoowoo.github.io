#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (6) reshape(), view :  PyTorch tensors-----------------------------

import torch

# C = torch.arange(12)                # tensor([0, 1, ..., 11])
# print(C.reshape(3, 4))              # shape (3,4)
# print(C.reshape(-1, 6))             # -1 lets PyTorch infer -> (2,6)
# print(C.view(-1))                   # flat view if possible

# ==========================================================================
# Create a contiguous tensor
A = torch.arange(12)
print("A:", A)

# Reshape works fine
print("A.reshape(3,4):\n", A.reshape(3,4))

# Make a non-contiguous tensor by transposing
B = A.reshape(3,4).t()   # transpose
C = A.reshape(3,4)   
print("\nB (transposed):\n", B)
print("Is B contiguous?", B.is_contiguous())
print("Is C contiguous?", C.is_contiguous())

# view requires contiguous memory -> will raise an error
try:
    print(B.view(12))   # RuntimeError
except RuntimeError as e:
    print("B.view(12) failed:", e)

# reshape can handle non-contiguous tensors by copying
print("B.reshape(12):", B.reshape(12))  #  works


# E = torch.arange(12).reshape(3,4).t()  # non-contiguous
# print("Is contiguous?", E.is_contiguous())

# # flatten → always returns contiguous copy
# print(E.flatten().is_contiguous())  # True

# # view(-1) → only works if contiguous
# try:
#     print(E.view(-1))
# except RuntimeError as e:
#     print("view failed:", e)