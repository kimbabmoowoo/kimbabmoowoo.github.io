#  Lecture 02-PyTorch01 
#
#  Basic Example (1) 
#     Linear regression (2) 
# ======================================

import torch
import torch.nn as nn

# device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# inputs
x = torch.randn(5, 3, device=device)                 # (5, 3)
target = torch.full((5, 1), 0.5, device=device)      # (5, 1)

# model: y = x @ w,  (no bias)
model = nn.Linear(3, 1, bias=False).to(device)

# optimizer & loss
optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
loss_fn = nn.MSELoss()

for step in range(20):
    optimizer.zero_grad(set_to_none=True)
    pred = model(x)                     # (5, 1)
    loss = loss_fn(pred, target)        # MSE
    loss.backward()
    optimizer.step()

    if step % 5 == 0:
        with torch.no_grad():
            # model.weight shape: (1, 3)  
            print(f"Step {step:2d} | loss {loss.item():.4f} | w = {model.weight.detach()}")

with torch.no_grad():
    print("Final w:", model.weight.detach())
    print(target.shape)