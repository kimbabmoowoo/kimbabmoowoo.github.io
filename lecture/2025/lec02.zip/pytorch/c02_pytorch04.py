#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (4) Broadcasting of PyTorch tensors-----------------------------

import torch

A = torch.tensor([[1, 2, 3],
                  [4, 5, 6]])   # shape (2,3)

d = 10
print(A + d)
# tensor([[11, 12, 13],
#         [14, 15, 16]])

print(type(d))       # <class 'int'>
print(type(A + d))   # <class 'torch.Tensor'>


A = torch.tensor([[1, 2, 3],
                  [4, 5, 6]])   # shape (2,3)
b = torch.tensor([10, 20, 30])  # shape (3,)

print(A + b)
# tensor([[11, 22, 33],
#         [14, 25, 36]])
