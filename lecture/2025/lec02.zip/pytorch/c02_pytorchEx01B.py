#  Lecture 02-PyTorch01 
#
#  Simplest Example (1) 
#     Linear regression with nn.Module
# ======================================

import torch
import torch.nn as nn

# Reproducibility
torch.manual_seed(0)

# 1) Ground-truth (random) + data
a_star, b_star = torch.randn(1), torch.randn(1)
N = 100
x = torch.linspace(-5, 5, N).unsqueeze(1)  # .unsqueeze(1) adds a new dimension at index 1 : making a column vector
y = a_star * x + b_star + 0.5 * torch.randn(N, 1)

# 2) Model, loss, optimizer
model = nn.Linear(1, 1)              # y ≈ ax + b
criterion = nn.MSELoss()
#optimizer = torch.optim.Adam(model.parameters(), lr=0.05) 
optimizer = torch.optim.SGD(model.parameters(), lr=0.05)   

# 3) Train
for _ in range(3000):                 # more steps → steadier convergence
    y_hat = model(x)
    loss = criterion(y_hat, y)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

a, b = model.weight.item(), model.bias.item()
print(f"True: a* = {a_star.item():.4f}, b* = {b_star.item():.4f}")
print(f"Learned: a = {a:.4f}, b = {b:.4f}")
print(f"MSE: {loss.item():.4f}")