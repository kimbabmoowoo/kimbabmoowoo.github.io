#  Lecture 02-PyTorch01 
#
#  Basic Example (1) 
#     Linear regression (1) 
# ======================================

import torch

# device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# inputs
x = torch.randn(5, 3, device=device)   # 5 samples, 3 features
target = torch.tensor([[0.5]]*5, device=device)  # target scalar (broadcastable)

# parameter to learn
w = torch.randn(3, 1, device=device, requires_grad=True)

# optimizer
optimizer = torch.optim.SGD([w], lr=0.1)

for step in range(20):
    pred = x @ w                        # (5,1)
    loss = ((pred - target)**2).mean()  # MSE loss
    
    # autograd
    optimizer.zero_grad()   # Clear old gradients (set .grad to zero)
    loss.backward()         # Compute gradients of loss w.r.t parameters
    optimizer.step()        # Update parameters using gradients

    if step % 5 == 0:  # print every 5 steps
        print(f"Step {step:2d} | loss {loss.item():.4f} | w = {w.detach().T}")

print("Final w:", w.detach().T)
print(target.shape)