#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (1) Create PyTorch tensors  -------------------------------------------

import torch

a = torch.tensor([1, 2, 3])
b = torch.tensor([[1, 2, 3],
                  [4, 5, 6]])

print(a)                 # tensor([1, 2, 3])
print(b)                 # 2 rows, 3 cols

print(a.ndim)            # number of axes: 1
print(b.ndim)            # number of axes: 2
print(b.shape)           # torch.Size([2, 3]) -> 2 rows, 3 columns
print(b.dtype)           # data type (e.g., torch.int64)

# Make tensors of zeros/ones or a range
z = torch.zeros((2, 3))                     # shape 2x3, all zeros (float)
o = torch.ones((3, 2), dtype=torch.int32)   # shape 3x2, all ones (int)
r = torch.arange(0, 10, 2)                  # [0, 2, 4, 6, 8]
lin = torch.linspace(0, 1, steps=5)         # [0., 0.25, 0.5, 0.75, 1.]

print(z, o, r, lin, sep="\n")