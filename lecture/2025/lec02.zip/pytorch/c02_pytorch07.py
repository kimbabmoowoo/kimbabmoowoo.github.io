#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (7) Matrix multiplication :  PyTorch tensors-----------------------------

import torch

A = torch.tensor([[1., 2.],
                  [3., 4.]])

b = torch.tensor([1., 2.])  # define vector b

row = b[None, :]          # shape: (1, 2) ← row vector
col = b[:, None]          # shape: (2, 1) ← column vector

# Equivalent forms
row2 = b.reshape(1, -1)   # (1, 2)
col2 = b.reshape(-1, 1)   # (2, 1)

# Matrix multiplication
print(b @ A)              # (2,) @ (2,2) → (2,)   (behaves like a row in this context)
print(A @ b)              # (2,2) @ (2,) → (2,)   (behaves like a column in this context)

print(row @ A)            # (1,2) @ (2,2) → (1,2)
print(A @ col)            # (2,2) @ (2,1) → (2,1)
