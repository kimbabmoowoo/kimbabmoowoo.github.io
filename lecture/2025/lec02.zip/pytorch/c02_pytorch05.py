#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (5) dim:  PyTorch tensors-----------------------------

import torch

# B = torch.tensor([[1, 2, 3],
#                   [4, 5, 6]], dtype=torch.float32)  # set dtype=float for convenient mean calculation

# print(B.sum())                     # tensor(21.)
# print(B.mean(), B.min(), B.max())  # mean, min, max

# # PyTorch supports median and std as well
# print(B.median(), B.std())         # median, standard deviation
# print(B.median(), B.std()) 

# # axis (dim in PyTorch) -------------------------------------------
# print(B.sum(dim=0))   # column sums -> tensor([5., 7., 9.])
# print(B.sum(dim=1))   # row sums    -> tensor([ 6., 15.])

# # column-wise mean (dim=0)
# col_means = B.mean(dim=0)
# print("axis=0 (columns) mean:", col_means)  # tensor([2.5000, 3.5000, 4.5000])

# # row-wise mean (dim=1)
# row_means = B.mean(dim=1)
# print("axis=1 (rows) mean:", row_means)     # tensor([2., 5.])


# ==============================================================
import torch

A = torch.tensor([1, 2, 3, 4, 5, 6], dtype = float)  
print(A.median(), A.std())            # tensor(3.), tensor(1.8708)
print(torch.median(A), torch.std(A))  # the same as the above
print(torch.std(A, unbiased=False))   # matches np.std
   
# import numpy as np
# B = np.array([1, 2, 3, 4, 5, 6])
# print(np.median(B), np.std(B))  # 3.5, 1.7078
