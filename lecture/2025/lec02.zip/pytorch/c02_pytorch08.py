#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (8) torch.stack() :  PyTorch tensors-----------------------------

import torch

X = torch.tensor([1, 2, 3])
Y = torch.tensor([4, 5, 6])

# print(torch.stack([X, Y], dim=0))  # [[1, 2, 3],
#                                    #  [4, 5, 6]]

# print(torch.stack([X, Y], dim=1))  # [[1, 4],
#                                    #  [2, 5],
#                                    #  [3, 6]]

# print(torch.vstack([X, Y]))        # [[1, 2, 3],
#                                    #  [4, 5, 6]]

# print(torch.hstack([X, Y]))        # [1, 2, 3, 4, 5, 6]

# =========================================================

X = torch.tensor([1, 2, 3])
Y = torch.tensor([4, 5, 6])
print(X.shape, Y.shape)

a = torch.stack([X, Y], dim=0)
b = torch.stack([X, Y], dim=1)

print(a.shape)  # torch.Size([2, 3])
print(b.shape)  # torch.Size([3, 2])
