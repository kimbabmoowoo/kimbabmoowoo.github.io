#  Lecture 02-PyTorch01 
#
#  PyTorch
# ======================================================================

# (3) Vectorization of PyTorch tensors-----------------------------

import torch

a = torch.arange(5)   # tensor([0, 1, 2, 3, 4])
b = torch.arange(5)   # tensor([0, 1, 2, 3, 4])

result = a + b        # vectorization
print(result)         # tensor([0, 2, 4, 6, 8])

numbers = torch.arange(5)
squared = numbers ** 2  # vectorization
print(squared)          # tensor([ 0,  1,  4,  9, 16])